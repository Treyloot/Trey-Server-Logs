--[[ FX Information ]]--

fx_version 'cerulean'
lua54 'yes' 
game 'gta5'

--[[ Resource Information ]]--

name         'trey-logs'
author       'Trey'
version      '1.0.0'
repository   ''
description  'Add join/leave logs to your fivem server'

--[[ Manifest ]]--

server_scripts {
	'server.lua'
}
