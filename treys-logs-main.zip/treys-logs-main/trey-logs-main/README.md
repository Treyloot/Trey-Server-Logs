Join/Leave logs for your fivem server.

0.00ms fully optimized (dont mind it being called sorrow-logs its cause its for my server 🤣)

![image](https://github.com/Jackster-off/js-logs/assets/126988682/f01cb02a-3855-4546-9b01-1abf1850d17b)

How to configure:

1) Open server.lua 
2) change the values at the top to your webhook, server name and logo.
